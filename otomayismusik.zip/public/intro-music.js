window.addEventListener('load', () => {
  const audio = document.getElementById('intro-audio');
  if(audio) {
    setTimeout(() => {
      audio.play().catch(() => {});
    }, 500);
  }
});