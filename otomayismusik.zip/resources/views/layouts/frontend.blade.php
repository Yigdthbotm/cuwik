<!-- Tambahan Musik Intro -->
<audio id="intro-audio" autoplay hidden>
  <source src="/intro.mp3" type="audio/mpeg">
</audio>
<script src="/intro-music.js"></script>