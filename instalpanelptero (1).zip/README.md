# Instalasi Addon Pterodactyl

Jalankan `bash install.sh` setelah unzip.