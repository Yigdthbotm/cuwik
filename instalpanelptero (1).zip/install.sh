#!/bin/bash

echo "=== [ Instalasi Addon Panel Pterodactyl ] ==="

PANEL_DIR="/var/www/pterodactyl"

if [ ! -d "$PANEL_DIR" ]; then
    echo "[ERROR] Folder panel tidak ditemukan di $PANEL_DIR"
    exit 1
fi

# Backup routes dan controller
cp "$PANEL_DIR/routes/web.php" "$PANEL_DIR/routes/web.php.bak" 2>/dev/null
cp "$PANEL_DIR/app/Http/Controllers/Admin/ServerController.php" "$PANEL_DIR/app/Http/Controllers/Admin/ServerController.php.bak" 2>/dev/null

# Salin file modifikasi
cp -r panel_mods/routes/* "$PANEL_DIR/routes/" 2>/dev/null
cp -r panel_mods/app/* "$PANEL_DIR/app/" 2>/dev/null
cp -r panel_mods/resources/* "$PANEL_DIR/resources/" 2>/dev/null

# Salin musik intro
cp intro.mp3 "$PANEL_DIR/public/intro.mp3" 2>/dev/null

# Tambahkan musik ke welcome view
WELCOME_VIEW="$PANEL_DIR/resources/views/welcome.blade.php"
if [ -f "$WELCOME_VIEW" ] && ! grep -q "intro.mp3" "$WELCOME_VIEW"; then
    echo '<audio autoplay loop><source src="/intro.mp3" type="audio/mpeg"></audio>' >> "$WELCOME_VIEW"
fi

echo "[✓] Addon berhasil diinstal ke $PANEL_DIR"
echo "Silakan edit .env.example dan jalankan: php artisan config:clear"
