
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Panel</title>
</head>
<body>
  @yield('content')

  <!-- Musik Intro Aman -->
<audio id="intro-audio" autoplay hidden>
  <source src="/intro.mp3" type="audio/mpeg">
</audio>

<script>
  function playAudio() {
    const audio = document.getElementById('intro-audio');
    if (audio) audio.play().catch(() => {});
    document.removeEventListener('click', playAudio);
  }

  document.addEventListener('click', playAudio);
</script>
</body>
</html>
