<!-- Tambahan Musik Intro -->
<audio autoplay id="intro-audio" hidden>
  <source src="/intro.mp3" type="audio/mpeg">
</audio>
<script>
  const audio = document.getElementById('intro-audio');
  window.addEventListener('load', () => {
    setTimeout(() => {
      audio.play().catch(e => {});
    }, 500);
  });
</script>