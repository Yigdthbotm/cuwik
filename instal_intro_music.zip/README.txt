=== INSTALASI MUSIK INTRO PADA PANEL PTERODACTYL ===

1. Upload semua isi folder ini ke direktori panel Pterodactyl kamu.
   Biasanya: /var/www/pterodactyl

2. Ganti file public/intro.mp3 dengan musik yang kamu mau.

3. Jalankan perintah berikut untuk membangun ulang aset panel:
   cd /var/www/pterodactyl
   php artisan view:clear
   php artisan config:clear
   php artisan optimize
   npm install && npm run build:production

4. Selesai! Musik akan otomatis diputar saat halaman panel dibuka.

NOTE: File `intro.mp3` sebaiknya ukuran kecil agar tidak memberatkan loading.